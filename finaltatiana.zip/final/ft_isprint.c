int ft_isprint(int c)
{
	if (c >= (char)32 && c<= (char)126)
	{
          	return 1;
	}
	return 0;
}
