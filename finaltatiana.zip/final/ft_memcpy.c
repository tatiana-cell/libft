#include "libft.h"
void * ft_memcpy (void *dst, const void *src, size_t len)
{
  unsigned char * d;
  unsigned char * s;
  size_t i;

  
  i = 0;
  d = (unsigned char *)dst;
  s = (unsigned char *)src;

  while (i < len)
  {
      *d++ = *s++;
       i++;
  }
  
  return dst;
}
