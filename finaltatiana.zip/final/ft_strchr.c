#include "libft.h"
char	*ft_strchr(const char *s, int c)
{
  int	i;

	if (!s)
		return (NULL);
	i = 0;
	while (s[i])
	{
		if (s[i] == (char)c)
			return ((char*)(s + i));
		i++;
	}
	if (s[i] == (char)c)
		return ((char*)(s + i));
	return (NULL); 
   
   
   
   
   
   
   
   /* char chr = c + '0';
    if (!s)
        return (NULL);
      
    while (*s )
    {
        if (*s == chr)
        {
            return ((char*)s);
        }    
        s++;
    }


    return NULL;*/

}