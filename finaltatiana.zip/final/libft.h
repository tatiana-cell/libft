/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tkurashe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/04 18:23:30 by tkurashe          #+#    #+#             */
/*   Updated: 2021/12/09 17:32:19 by tkurashe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef LIBFT_H
# define LIBFT_H
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stddef.h>


//int	ft_putchar(char c);
size_t	ft_strlen(const char *s);
int	ft_isdigit(int c);
int	ft_isalpha(int c);
int	ft_isalnum(int c);
int	ft_isprint(int c);

//size_t strlcpy (char *dest, const char *src, size_t size);
size_t ft_strlcpy (char *dest, const char *src, size_t size);
//size_t strlcat(char *dst, const char *src, size_t size);
size_t ft_strlcat(char *dst, const char *src, size_t size);
//size_t ftr_strlcat(char *dst, const char *src, size_t size);
int ft_isascii(int c);

int ft_toupper(int c);
//int ft_tolower(int c);
char	* ft_strchr(const char *s, int c);
void    * ft_memset(void *s, int c, size_t n);
void 	ft_bzero(void *s, size_t n);
void    * ft_memmove(void* dst, const void* src, size_t n);
void    * ft_memcpy (void *dst, const void *src, size_t len);
char    * ft_strrchr(const char *s, int c);
int 	ft_strncmp(const char *s1, const char *s2, size_t n);
void * ft_memchr(const void *s, int c, size_t n);
int ft_memcmp(const void *s1, const void *s2, size_t n);

#endif
